import java.util.*;
public class MainClass {

	public static void main(String[] args) throws NegativeValueException, OutOfRangeException, NegativeDaysException {
		int choice = 0;
		do
		{
		int interestGained=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("MAIN MENU");
		System.out.println("---------");
		System.out.println("\t1.Interest Calculator -SB");
		System.out.println("\t2.Interest Calculator -FD");
		System.out.println("\t3.Interest Calculator -RD");
		System.out.println("\t4.Exit");
		System.out.print("Enter your option (1..4):");
		
		try
		{
		choice = sc.nextInt();
		switch(choice)
		{
		case 1:
		{
			System.out.print("Enter the average amount in your account:");
				double amount = sc.nextDouble();
				if(amount<0)
					throw new NegativeValueException();
				else
				{
				SBAccount sb = new SBAccount(amount);
				interestGained = (int)(sb.calculateInterest());
				}
				System.out.printf("Interest gained: Rs. %d\n",interestGained);
				break;
			
		}
		
		case 2:
		{
			System.out.print("Enter the FD Amount:");
			double amount = sc.nextDouble();
			if(amount<0)
				throw new NegativeValueException();
			System.out.println();
			System.out.print("Enter the no. of days:");
			int noOfDays = sc.nextInt();
			
			
			System.out.println();
			System.out.print("Enter your age:");
			int age = sc.nextInt();
				
			System.out.println();
			if(noOfDays>=7 && noOfDays<=366)
			{
			
			FDAccount fd = new FDAccount(amount,noOfDays,age);
			
			interestGained = (int)(fd.calculateInterest());
			
			System.out.printf("Interest gained is: Rs. %d\n",interestGained);
			}
			else if(noOfDays<0)
				{
					throw new NegativeDaysException();
					
				}
			else 
				{ throw new OutOfRangeException();
			 }
			break;
			
		}
		
		case 3:
		{
			System.out.print("Enter the RD Amount:");
			double amount = sc.nextDouble();
			if(amount<0)
				throw new NegativeValueException();
			System.out.println();
			System.out.print("Enter the no. of Months:");
			int months = sc.nextInt();
			if(months==6 || months==9 || months==12 || months==15 || months==18 || months==21)
			{
			System.out.println();
			System.out.print("Enter your monthly amount");
			double monthlyAmount = sc.nextDouble();
			System.out.println();
			System.out.print("Enter your age:");
			int age = sc.nextInt();
			if(age<=0 && age>=150)
				throw new OutOfRangeException();
			System.out.println();
			RDAccount rd = new RDAccount(amount,months,monthlyAmount,age);
			interestGained = (int)(rd.calculateInterest());
			if(interestGained!=-63)
			{
				System.out.printf("Interest gained is: %d\n",interestGained);
				break;
			}
			}
			else 
				{
				System.out.println("Please provide valid inputs!");
				}
		System.out.println("No of Months are allowed: 6,9,12,15,18,21 and age must be between 0-150");
		break;
		}
		case 4:
		{
			System.exit(0);
		}
		default:
			System.out.println("Please input a valid choice !");
		}
		}
		
		catch(NegativeValueException e)
		{
			System.out.println(e);
		}
		catch(InputMismatchException e)
		{
			System.out.println("Please input a valid value !");
		}
		
		catch(OutOfRangeException e)
		{
			System.out.println("Invalid value! Age is allowed between 0-150 & days are allowed between 6 to 367");
		}
		catch(NegativeDaysException e)
		{
			System.out.println(e);
		}
		
		
		System.out.print("\n\n");
		
	
}
		while(choice!=4);
	}
}
		
