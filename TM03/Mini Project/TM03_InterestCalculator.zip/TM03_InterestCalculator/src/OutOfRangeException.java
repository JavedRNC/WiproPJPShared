
public class OutOfRangeException extends Exception {
	public String toString()
	{
		return "Please input values between 7-366 in case of days";
	}
}
