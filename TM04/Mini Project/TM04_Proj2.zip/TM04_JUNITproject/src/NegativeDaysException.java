
public class NegativeDaysException extends Exception {
	public String toString()
	{
		return "Invalid Number of days. Please enter non-negative values.";
	}

}
