import org.junit.runner.RunWith;
import org.junit.runners.Suite;



	@RunWith(Suite.class)
	@Suite.SuiteClasses({FDAccountTest.class,RDAccountTest.class,SBAccountTest.class,
		NegativeDaysExceptionTest.class,NegativeValueExceptionTest.class,OutOfRangeExceptionTest.class})
	public class AllTest {
		
	}
