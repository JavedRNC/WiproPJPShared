import static org.junit.Assert.*;

import org.junit.Test;

public class SBAccountTest {

	@Test
	public void testCalculateInterest() {
		SBAccount sbAccount = new SBAccount(1000);
		assertEquals(40, sbAccount.calculateInterest(),1);
	}

}
