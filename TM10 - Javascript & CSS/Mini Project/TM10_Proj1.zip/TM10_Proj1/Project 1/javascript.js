window.setTimeout("Warning()",180000);

function Warning()
{
    alert("3 minutes past");
}

function validateFields()
{
    var firstName = document.form1.fname.value;
    var lastName = document.form1.lname.value;

    var pass = document.form1.pass.value;
    var cnfpass = document.form1.cnfpass.value;

    var tel = document.form1.mno.value;
    var dob = document.form1.dobtxt.value;
    var email = document.form1.emailtxt.value;

    if(firstName=="" || lastName=="" || pass=="" || cnfpass=="" || tel=="" || dob=="" || email=="")
    {
        alert("All fields are required !");
        return false;
    }
    if(pass.length<6 || pass.length>20 || cnfpass.length<6 || cnfpass.length>20 )
    {
        alert("Password length must be of 6 to 20 characters ");
            return false;

    }
    else if(pass!=cnfpass)
        {
            alert("Password and Confirm password is not same");
        return false;
        }

    var regexmno = /([0-9]{3}[-][0-9]{3}[-][0-9]{4})|([0-9]{3}[.][0-9]{3}[.][0-9]{4})|([0-9]{3}[ ][0-9]{3}[ ][0-9]{4})/;

    if(!(tel.match(regexmno)))
    {
        alert("Phone no should be in proper format. Allowed formats: XXX-XXX-XXXX or XXX.XXX.XXXX or XXX XXX XXXX");
        return false;
    }

    var regexdob = /[0-9]{2}-[0-9]{2}-[0-9]{4}/;
    if(!(dob.match(regexdob)))
    {
        alert("Date of Birth must be in DD-MM-YYYY format");
        return false;
    }

    var regexemail = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    if(!(email.match(regexemail)))
    {
        alert("Email is not in valid format");
        return false;
    }


return false;
    
}