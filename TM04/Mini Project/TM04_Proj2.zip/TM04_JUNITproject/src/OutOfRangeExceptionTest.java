
import org.junit.Test;

public class OutOfRangeExceptionTest {

	@Test(expected = OutOfRangeException.class)
	public void testToString() throws OutOfRangeException {
		int value = 7;
		if(value<=8)
			throw new OutOfRangeException();
	}

}
