
public class NegativeValueException extends Exception {
	public String toString()
	{
		return "NegativeValueException found! Please input a non-negative value!";
	}
}
