import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class VideoStoreTest {
	
	VideoStore vs = new VideoStore();
	@Before
	public void init()
	{
		
		vs.addVideo("Video1");
		vs.addVideo("Video2");
		
	}
	
	@Test
	public void testAddVideo() {
		vs.addVideo("Video3");
		assertSame("Video3",vs.store[2].getName());
	}

	@Test
	public void testDoCheckOut() {
		vs.addVideo("Video3");
		vs.store[2].doCheckout();
		assertTrue(vs.store[2].getCheckout());
		
		
	}

	@Test
	public void testDoReturn() {
		vs.doReturn("Video1");
		assertFalse(vs.store[0].getCheckout());
	}

	@Test
	public void testReceiveRating() {
		vs.addVideo("Video3");
		vs.store[2].receiveRating(4);
		assertSame(4,vs.store[2].getRating());
	}

	@Test
	public void testListInventory() {
		vs.addVideo("Video3");
		assertSame("Video1",vs.store[0].getName());
		assertSame("Video2",vs.store[1].getName());
		assertSame(0,vs.store[1].getRating());
		vs.store[1].doReturn();
		assertFalse(vs.store[1].getCheckout());
	}

}
