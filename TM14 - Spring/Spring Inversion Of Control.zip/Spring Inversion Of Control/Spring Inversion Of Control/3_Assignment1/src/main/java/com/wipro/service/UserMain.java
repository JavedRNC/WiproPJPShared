package com.wipro.service;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.wipro.sample.DrawShape;
import com.wipro.sample.Shape;

public class UserMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Resource resource=new ClassPathResource("beans.xml");  
	    BeanFactory factory=new XmlBeanFactory(resource);
	    
	    DrawShape ds = (DrawShape) factory.getBean("DrawShapeBean");
	    ds.show();
	}
}
