import org.junit.Test;

public class NegativeValueExceptionTest {

	@Test(expected = NegativeValueException.class)
	public void testToString() throws NegativeValueException{
		int value = -8;
		if(value<0)
			throw new NegativeValueException();	}

}
