package com.wipro.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wipro.bean.Player;

public class UserMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext factory=new ClassPathXmlApplicationContext("beans.xml");
		Player play = (Player)factory.getBean("PlayerBean");
		play.show();
	}

}
