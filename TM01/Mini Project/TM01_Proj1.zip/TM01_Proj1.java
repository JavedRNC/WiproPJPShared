import java.util.*;

public class TM01_Proj1
{
	public static void main(String[] args)
	{	String[][] EmployeeDB = 
   {{"1001","Ashish","01/04/2009","e","R&D","20000","8000","3000"},
	{"1002", "Sushma","23/08/2012","c", "PM", "30000", "12000", "9000"},
	{"1003","Rahul" ,"12/11/2008" ,"k", "Acct", "10000", "8000", "1000"},
	{"1004","Chahat", "29/01/2013" ,"r", "Front Desk",	"12000", "6000", "2000"},
	{"1005", "Ranjan", "16/07/2005" ,"m" ,"Engg", "50000", "20000", "20000"},
	{"1006", "Suman", "1/1/2000", "e", "Manufacturing", "23000" ,"9000", "4400"},
	{"1007","Tanmay", "12/06/2006", "c", "PM", "29000", "12000", "10000"}};
	
	String[][] AllowanceDB =
    {{"e" ,"Engineer" ,"20000"},
	{"c","Consultant","32000"},
	{"k" ,"Clerk" ,"12000"},
	{"r","Receptionist", "15000"},
	{"m","Manager", "40000"}};
	
	String Designation = "";
	int Salary = 0;
	boolean isFound = false;
	int i=0;
	for(i=0;i<EmployeeDB.length;i++)
		{	
			if(EmployeeDB[i][0].equals(args[0]))
			{	isFound = true;
				switch(EmployeeDB[i][3])
				{
					case "e":
					{
						for(int k=0;k<AllowanceDB.length;k++)
						{
							if(AllowanceDB[k][0] == "e")
							{
								Designation = AllowanceDB[k][1];
								Salary = Integer.parseInt(AllowanceDB[k][2]) + Integer.parseInt(EmployeeDB[i][5]) + Integer.parseInt(EmployeeDB[i][6]) - Integer.parseInt(EmployeeDB[i][7]);
								
							}
						}
						break;
					}
					case "c":
					{
						for(int k=0;k<AllowanceDB.length;k++)
						{
							if(AllowanceDB[k][0] == "c")
							{
								Designation = AllowanceDB[k][1];
								Salary = Integer.parseInt(AllowanceDB[k][2]) + Integer.parseInt(EmployeeDB[i][5]) + Integer.parseInt(EmployeeDB[i][6]) - Integer.parseInt(EmployeeDB[i][7]);
								
							}
						}
						break;
					}
					case "k":
					{
						for(int k=0;k<AllowanceDB.length;k++)
						{
							if(AllowanceDB[k][0] == "k")
							{
								Designation = AllowanceDB[k][1];
								Salary = Integer.parseInt(AllowanceDB[k][2]) + Integer.parseInt(EmployeeDB[i][5]) + Integer.parseInt(EmployeeDB[i][6]) - Integer.parseInt(EmployeeDB[i][7]);
								
							}
						}
						break;
					}
					case "r":
					{
						for(int k=0;k<AllowanceDB.length;k++)
						{
							if(AllowanceDB[k][0] == "r")
							{
								Designation = AllowanceDB[k][1];
								Salary = Integer.parseInt(AllowanceDB[k][2]) + Integer.parseInt(EmployeeDB[i][5]) + Integer.parseInt(EmployeeDB[i][6]) - Integer.parseInt(EmployeeDB[i][7]);
								
							}
						}
						break;
					}
					
					case "m":
					{
						for(int k=0;k<AllowanceDB.length;k++)
						{
							if(AllowanceDB[k][0] == "m")
							{
								Designation = AllowanceDB[k][1];
								Salary = Integer.parseInt(AllowanceDB[k][2]) + Integer.parseInt(EmployeeDB[i][5]) + Integer.parseInt(EmployeeDB[i][6]) - Integer.parseInt(EmployeeDB[i][7]);
								
							}
						}
						break;
					}
				}
				
				System.out.println("Emp No.  Emp Name  Department  Designation  Salary");
				System.out.println(EmployeeDB[i][0]+ "  "+EmployeeDB[i][1]+ "  "+EmployeeDB[i][4]+"  "+ Designation+ "  "+Salary);
				break;
			}
			
		
		}
		
		if(isFound == false)
		{
			System.out.println("There is no employee with empid:"+args[0]);
		}
		
	
		
    }
}