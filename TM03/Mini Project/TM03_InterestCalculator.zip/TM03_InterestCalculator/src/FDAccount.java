
public class FDAccount extends Account{
double interestRate;
double amount;
int noOfDays;
int ageOfACHolder;
FDAccount(double amount,int noOfDays,int ageOfACHolder)
{
	
	this.amount = amount;
	this.noOfDays = noOfDays;
	this.ageOfACHolder = ageOfACHolder;
}
double calculateInterest()
{
	if(noOfDays>=7 && noOfDays<=14 && ageOfACHolder<=60 && amount<10000000)
	{
		interestRate = (amount*4.5)/100;
		return interestRate;
	}
	else if(noOfDays>=7 && noOfDays<=14 && ageOfACHolder>60 && amount<10000000)
	{
		interestRate = (amount*5.00)/100;
		return interestRate;
	}
	else if(noOfDays>=7 && noOfDays<=14 && amount>10000000)
	{
		interestRate = (amount*6.5)/100;
		return interestRate;
	}
	else if(noOfDays>=15 && noOfDays<=29 && ageOfACHolder<=60 && amount<10000000)
	{
		interestRate = (amount*4.75)/100;
		return interestRate;
	}
	else if(noOfDays>=15 && noOfDays<=29 && ageOfACHolder>60 && amount<10000000)
	{
		interestRate = (amount*5.25)/100;
		return interestRate;
	}
	else if(noOfDays>=15 && noOfDays<=29 && amount>10000000)
	{
		interestRate = (amount*6.75)/100;
		return interestRate;
	}
	else if(noOfDays>=30 && noOfDays<=45 && ageOfACHolder<=60 && amount<10000000)
	{
		interestRate = (amount*5.50)/100;
		return interestRate;
	}
	else if(noOfDays>=30 && noOfDays<=45 && ageOfACHolder>60 && amount<10000000)
	{
		interestRate = (amount*6.00)/100;
		return interestRate;
	}
	else if(noOfDays>=30 && noOfDays<=45 && amount>10000000)
	{
		interestRate = (amount*6.75)/100;
		return interestRate;
	}
	else if(noOfDays>=46 && noOfDays<=60 && ageOfACHolder<=60 && amount<10000000)
	{
		interestRate = (amount*7.00)/100;
		return interestRate;
	}
	else if(noOfDays>=46 && noOfDays<=60 && ageOfACHolder>60 && amount<10000000)
	{
		interestRate = (amount*7.50)/100;
		return interestRate;
	}
	else if(noOfDays>=46 && noOfDays<=60 && amount>10000000)
	{
		interestRate = (amount*8.00)/100;
		return interestRate;
	}
	else if(noOfDays>=61 && noOfDays<=184 && ageOfACHolder<=60 && amount<10000000)
	{
		interestRate = (amount*7.50)/100;
		return interestRate;
	}
	else if(noOfDays>=61 && noOfDays<=184 && ageOfACHolder>60 && amount<10000000)
	{
		interestRate = (amount*8.00)/100;
		return interestRate;
	}
	else if(noOfDays>=61 && noOfDays<=184 && amount>10000000)
	{
		interestRate = (amount*8.50)/100;
		return interestRate;
	}
	else if(noOfDays>=185 && noOfDays<=366 && ageOfACHolder<=60 && amount<10000000)
	{
		interestRate = (amount*8.00)/100;
		return interestRate;
	}
	else if(noOfDays>=185 && noOfDays<=366 && ageOfACHolder>60 && amount<10000000)
	{
		interestRate = (amount*8.50)/100;
		return interestRate;
	}
	else if(noOfDays>=185 && noOfDays<=366 && amount>10000000)
	{
		interestRate = (amount*10.00)/100;
		return interestRate;
	}
	else 
	{
		
		return -98;
	}
}
}
