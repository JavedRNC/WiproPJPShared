import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Test;

public class VideoTest {

	Video v = new Video("Matrix");

	@Test
	public void testGetName() {
		Video v = new Video("Matrix");
		assertEquals("Matrix",v.getName());
		
	}


	@Test
	public void testDoReturn() {
		v.doReturn();
		assertFalse(v.getCheckout());
	}

	@Test
	public void testDoCheckOut()
	{
		v.doCheckout();
		assertTrue(v.getCheckout());
	}
	
	@Test 
	public void testReceiveRating()
	{
		v.receiveRating(4);
		assertSame(4,v.getRating());
		
	}

	@Test
	public void testGetRating() {
		v.receiveRating(9);
		assertEquals(9,v.getRating());
	}

	@Test
	public void testGetCheckout() {
		v.doCheckout();
		assertTrue(v.getCheckout());
	}
	
	
	

}
