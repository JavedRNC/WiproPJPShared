import static org.junit.Assert.*;

import org.junit.Test;

public class FDAccountTest {

	@Test
	public void testCalculateInterest() {
		FDAccount fd = new FDAccount(3000,8,25);
		assertEquals(135.00, fd.calculateInterest(), 0.9);
	}


}
