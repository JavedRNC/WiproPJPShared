package com.wipro.sample;

public class Rectangle extends Shape {
	public void draw() {
		System.out.println("Drawing Rectangle");
	}  
}