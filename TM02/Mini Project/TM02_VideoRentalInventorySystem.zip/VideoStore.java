public class VideoStore 
{	int vcount = 0;
	Video[] store = new Video[999999];
	
	void addVideo(String name)
	{
		Video video = new Video(name);
		store[vcount++] = video;
		System.out.println("Video \""+ video.videoName+"\""+ " added successfully");
		
	}
	
	void doCheckOut(String name)
	{	boolean vidFound = false;
		for(Video vid: store)
		{	
			if(vid!=null && (vid.videoName).equals(name))
			{
				vidFound = true;
				vid.doCheckout();
				System.out.println("Video "+"\""+vid.videoName+"\""+" checked out successfully");
			}
				
		}
		if(vidFound==false)
		{
			System.out.println("ERROR 404 ! Video not found !");
		}
	}
	
	void doReturn(String name)
	{	boolean vidFound = false;
		for(Video vid: store)
		{	
			if(vid!=null && (vid.videoName).equals(name))
			{	vidFound = true;
				vid.doReturn();
				System.out.println("Video "+"\""+vid.videoName+"\""+" returned successfully");
				
			}
				
		}
		if(vidFound==false)
		{
			System.out.println("ERROR 404 ! Video not found !");
		}
	}
	
	void receiveRating(String name,int rating)
	{	boolean vidFound = false;
		for(Video vid: store)
		{
			if(vid!=null && (vid.videoName).equals(name))
			{	vidFound = true;
				vid.receiveRating(rating);
				System.out.println("Rating "+"\""+rating+"\"" + "has been mapped to the video "+"\""+name+"\"");
			}
				
		}
		if(vidFound==false)
		{
			System.out.println("ERROR 404 ! Video not found !");
		}
	}
	
	void listInventory()
	{
		System.out.println("----------------------------------------------------------------------");
		System.out.printf("%-20s %-8s %-20s %-10s %-10s\n","Video Name","|","Checkout Status","|","Rating");
		for(Video vid:store)
		{   if(vid!=null)
			System.out.printf("%-20s %-8s %-20b %-10s %-1d\n",vid.getName(),"|",vid.getCheckout(),"|",vid.getRating());
		}
		System.out.println("-----------------------------------------------------------------------");
	}
}