
public class RDAccount extends Account {
double interestRate;
double amount;
int noOfMonths;
double monthlyAmount;
int age;
RDAccount(double amount,int noOfMonths,double monthlyAmount,int age)
{
	this.monthlyAmount = monthlyAmount;
	this.amount = amount;
	this.noOfMonths = noOfMonths;
	this.age = age;
	
}
@Override
double calculateInterest()
{
	if(noOfMonths == 6 && age<=60 )
	{
		interestRate = monthlyAmount*6*7.50/100;
		return interestRate;
	}
	else if(noOfMonths == 6 && age>60)
	{
		return monthlyAmount*6*8/100;
	}
	else if(noOfMonths==9 && age<=60)
	{
		return monthlyAmount*9*7.75/100;
	}
	else if(noOfMonths == 9 && age>60)
	{
		return monthlyAmount*9*8.25/100;
	}
	else if(noOfMonths==12 && age<=60)
	{
		return monthlyAmount*12*8/100;
	}
	else if(noOfMonths==12 && age>60)
	{
		return monthlyAmount*12*8.5/100;
	}
	else if(noOfMonths==15 && age<=60)
	{
		return monthlyAmount*15*8.25/100;
	}
	else if(noOfMonths==15 && age>60)
	{
		return monthlyAmount*15*8.75/100;
	}
	else if(noOfMonths==18 && age<=60)
	{
		return monthlyAmount*18*8.5/100;
	}
	else if(noOfMonths==18 && age>60)
	{
		return monthlyAmount*18*9/100;
	}
	else if(noOfMonths==21 && age<=60)
	{
		return monthlyAmount*21*8.75/100;
	}
	else if(noOfMonths==21 && age>60)
	{
		return monthlyAmount*21*9.25/100;
	}
	else
	{
		return -63;
	}
	
		
}
}

