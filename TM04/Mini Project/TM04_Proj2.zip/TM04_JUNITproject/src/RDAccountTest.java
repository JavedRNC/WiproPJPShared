import static org.junit.Assert.*;

import org.junit.Test;

public class RDAccountTest {

	@Test
	public void testCalculateInterest() {
		RDAccount rdAccount = new RDAccount(5000, 6, 1000, 67);
		assertEquals(480, rdAccount.calculateInterest(),0.9);
	}

	
}
