import static org.junit.Assert.*;

import org.junit.Test;

public class NegativeDaysExceptionTest {

	@Test(expected=NegativeDaysException.class)
	public void testToString() throws NegativeDaysException {
		int noOfDays = -6;
		if(noOfDays<0)
			throw new NegativeDaysException();
		
	}

}
